package com.ex.hiworld.server.syu;

/**
 * Created by APP03 on 2018/6/8.
 */

public class FinalSyuModule {
    public static final int MODULE_CODE_MAIN			= 0;
    public static final int MODULE_CODE_RADIO			= 1;
    public static final int MODULE_CODE_BT				= 2;
    public static final int MODULE_CODE_DVD				= 3;
    public static final int MODULE_CODE_SOUND			= 4;
    public static final int MODULE_CODE_IPOD			= 5;
    public static final int MODULE_CODE_TV				= 6;
    public static final int MODULE_CODE_CANBUS			= 7;
}

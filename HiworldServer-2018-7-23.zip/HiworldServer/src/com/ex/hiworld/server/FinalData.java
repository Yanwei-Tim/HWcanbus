package com.ex.hiworld.server;

/**
 * Created by APP03 on 2018/6/23.
 */

public class FinalData {
//    public static final String HW_CLIENT_PKG = "com.ex.demo";
    public static final String HW_CLIENT_PKG = "com.hiworld.carset.noencry";
    public static final String HW_CLIENT_ACTION = "com.ex.hw.ServerKeepAlive";

    public static final String HW_CLIENT_CARPC_PKG = "com.hiworld.carcomputer";
    public static final String HW_CLIENT_CARPC_ACTION = "com.ex.hw.ServerKeepAlive";

//    public static final String FYT_HOST_SRV_PKG = "com.ex.demo";
//    public static final String FYT_HOST_SRV_ACTION = "com.ex.hw.ServerKeepAlive";


}

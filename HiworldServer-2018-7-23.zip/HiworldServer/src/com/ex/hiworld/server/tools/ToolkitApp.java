/**
 * ��Ȩ�������������Ƽ����޹�˾
 * ���:	 �»���
 * ���룺�������з���/Android��
 * ���ڣ�2015��1��1��
 */

package com.ex.hiworld.server.tools;

import android.graphics.PixelFormat;
import android.view.Gravity;
import android.view.WindowManager;

/**
 * Ӧ�����,������
 */
public class ToolkitApp {
	/**
	 * �����������͵Ĳ��ֲ���,�����ᴩ͸
	 */
	public static WindowManager.LayoutParams buildOverlayLayoutParams(int width, int height) {
		WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
    	lp.x = 0;
    	lp.y = 0;
		lp.width = width;//WindowManager.LayoutParams.WRAP_CONTENT;
    	lp.height = height;//WindowManager.LayoutParams.WRAP_CONTENT;
    	lp.format = PixelFormat.RGBA_8888;
//    	lp.type = WindowManager.LayoutParams.TYPE_SYSTEM_DIALOG|WindowManager.LayoutParams.TYPE_SYSTEM_OVERLAY;
    	lp.type = WindowManager.LayoutParams.TYPE_TOAST|WindowManager.LayoutParams.TYPE_SYSTEM_OVERLAY;
    	lp.flags = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
    	
    	lp.flags |= WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
    			|WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
    			|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;
    	lp.gravity = Gravity.LEFT|Gravity.TOP;
    	return lp;
	}
	
	/**
	 * �����Ի������͵Ĳ��ֲ���,���������Դ�͸
	 */
	public static WindowManager.LayoutParams buildDialogLayoutParams(int width, int height) {
		WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
    	lp.x = 0;
    	lp.y = 0;
		lp.width = width;//WindowManager.LayoutParams.WRAP_CONTENT;
    	lp.height = height;//WindowManager.LayoutParams.WRAP_CONTENT;
    	lp.format = PixelFormat.RGBA_8888;
    	lp.type = WindowManager.LayoutParams.TYPE_SYSTEM_OVERLAY;
    	lp.flags = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
    	
    	lp.flags |= WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
    			|WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
    			|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;
    	lp.gravity = Gravity.LEFT|Gravity.TOP;
    	return lp;
	}
	
//	public static boolean isScreenPort(){
//		boolean result = false;
//		
//		if(SystemProperties.get("ro.sf.hwrotation", "0").equals("90")
//				|| SystemProperties.get("ro.sf.hwrotation", "0").equals("180")
//				|| SystemProperties.get("ro.sf.hwrotation", "0").equals("270")
//				|| SystemProperties.get("ro.fyt.screen_port", "0").equals("1")){
//			result = true;
//		}
//			
//		return result;
//	}
}

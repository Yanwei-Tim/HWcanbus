package com.ex.hiworld.server.tools;

import android.content.Context;
import android.view.WindowManager;

public class PrintScreenView  {
	
	private static Context mCxt; 
	private static WindowManager windowMgr; 
	
	public static void init(Context c) {
		mCxt = c;
		debugView = new DebugView(c);
		
		windowMgr = (WindowManager) mCxt.getSystemService(Context.WINDOW_SERVICE);
		windowMgr.addView(debugView, debugView.getWindowLayoutParams());
	}
// 
	private static DebugView debugView;
	
	public static DebugView getMsgView() {
		return debugView;
	}

	public static void setDebugPrint(boolean debug) {
		debugView.setDbg(debug);
	}
	 
	
	
	
	
	
	
	
	
	
	
	
	
}

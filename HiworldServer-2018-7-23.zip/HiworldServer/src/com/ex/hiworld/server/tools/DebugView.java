/**
 * 版权：深圳深青联科技有限公司
 * 设计:	 柯华栋
 * 代码：深青联研发部/Android组
 * 日期：2015年1月1日
 */

package com.ex.hiworld.server.tools;

import java.util.Locale;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;

/**
 * 在屏幕显示调试信息
 */
public class DebugView extends View { 
	private boolean mDbg = true;
	
	private WindowManager.LayoutParams mLp = ToolkitApp.buildOverlayLayoutParams(
			WindowManager.LayoutParams.MATCH_PARENT,
			WindowManager.LayoutParams.MATCH_PARENT);
	
//-------------------------------------------------------------------------------------------------
	private int mLastIndex;				// 最新一条记录的位置
	private int mCount;					// 当前数目
	private final int MAX = 16;			// 最大显示的数目 
	private int CELL_HEIGHT = 20;
	private final int TEXT_SIZE = 16;
	private String[] mMsgs = new String[MAX];
	private int[] mColors = new int[MAX];
	
	private Paint mPaint = new Paint();
	private int mMsgCnt;
	
	public DebugView(Context context) {
		super(context);
		init();
	}
	
	private void init() {
		mPaint.setAntiAlias(true);
		mPaint.setTextSize(TEXT_SIZE);
		mPaint.setColor(Color.WHITE);
	}
	
	/**
	 * 设置调试标志
	 */
	public void setDbg(boolean flag) {
		mDbg = flag;
	}
	
	/**
	 * 是否调试 
	 */
	public boolean isDbg() {
		return mDbg;
	}
	
	public WindowManager.LayoutParams getWindowLayoutParams() {
		return mLp;
	}
	
	public void msg(String msg) {
		if (mDbg && msg != null) {
		//	Log.d("LG", "msg");
			HandlerUI.getInstance().post(new MessageHelper(msg));
		}
	}
	
	public void msg2(String msg) {
		if (mDbg && msg != null) {
			HandlerUI.getInstance().post(new MessageHelper(msg));
		}
	}

	public void msgHex(String str,byte[] data, int start, int length){
		if (mDbg && data != null) {
			if(data.length - start < length)
				length = data.length - start;
			String msg = str+" * ";
			String c = "";
			for (int i = 0; i < length ; i++) {
				c = Integer.toHexString(data[start + i]&0x0FF).toUpperCase(Locale.CHINA);
				if(c.length() < 2)
					c = "0"+c;
				msg += c + " ";
			}

			HandlerUI.getInstance().post(new MessageHelper(msg));
		}
	}
	public void msgHex(String str,int[] data, int start, int length){
		if (mDbg && data != null) {
			if(data.length - start < length)
				length = data.length - start;
			String msg = str+" * ";
			String c = "";
			for (int i = 0; i < length ; i++) {
				c = Integer.toHexString(data[start + i]&0x0FF).toUpperCase(Locale.CHINA);
				if(c.length() < 2)
					c = "0"+c;
				msg += c + " ";
			}

			HandlerUI.getInstance().post(new MessageHelper(msg));
		}
	}
	int []COLOR = new int[] {
		Color.RED, Color.WHITE, Color.GREEN, Color.YELLOW , Color.BLUE
	};
	
	private class MessageHelper implements Runnable {
		
		private String mMessage;
		
		public MessageHelper(String msg) {
			mMessage = msg;
		}

		@Override
		public void run() {
			mLastIndex++;
			mCount++;
			if (mLastIndex > MAX-1) {
				mLastIndex = 0;
			}
			if (mCount > MAX) {
				mCount = MAX;
			}
			mMsgCnt++;
			mMsgs[mLastIndex] = String.format("%06d @ %s", mMsgCnt, mMessage);
			mColors[mLastIndex] = COLOR[mLastIndex%COLOR.length];
			invalidate();
		}
	}
	
	@Override
	protected void onDraw(Canvas canvas) {
		if (mCount == 0) {
			return;
		}
		
		int x = 5;
		
		int index, count = mCount;
		
		int firstIndex = mLastIndex - count + 1;
		if (firstIndex < 0) {
			firstIndex += MAX;
		}
		
		if (firstIndex + count > MAX) {
			int rightCount = MAX - firstIndex;
			int leftCount = count-rightCount;
			for (int i = 0; i < rightCount; i++) {
				index = firstIndex + i;
				mPaint.setColor(mColors[index]);
				canvas.drawText(mMsgs[index], x, (i+1) * CELL_HEIGHT, mPaint);
			}
			
			for (int i = 0; i < leftCount; i++) {
				mPaint.setColor(mColors[i]);
				canvas.drawText(mMsgs[i], x, (rightCount+i+1) * CELL_HEIGHT, mPaint);
			}
		} else {
			for (int i = 0; i < count; i++) {
				index = firstIndex+i;
				mPaint.setColor(mColors[index]);
				canvas.drawText(mMsgs[index], x, (i+1) * CELL_HEIGHT, mPaint);
			}
		}
		
		//if (DataChip.getChipId() == FinalChip.CHIP_MST786)
	//		canvas.drawColor(0x0100FF00);	// 防止MST786视频穿透
	}
}
